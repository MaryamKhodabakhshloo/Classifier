import os
import pygame
import numpy as np
import time
from math import sin, radians, degrees, copysign
from pygame.math import Vector2
#################################################################################
class EGO_Car:
    def __init__(self, x, y, angle=90.0, length=4, max_steering=30, max_acceleration=2.5):
        self.position = Vector2(x, y)
        self.velocity = Vector2(5.0,0.0)
        self.angle = angle
        self.length = length
        self.max_acceleration = max_acceleration
        self.max_steering = max_steering
        self.max_velocity = 5.3
        self.brake_deceleration = 10
        self.free_deceleration = 1
        self.acceleration = 0.0
        self.steering = 0.0

    def update(self,dt):
        self.velocity += (self.acceleration * dt, 0)
        self.velocity.x = max(-self.max_velocity, min(self.velocity.x, self.max_velocity))#vehical velocity if it's in allowable range
        #print(self.velocity.x)
        if self.steering:
            turning_radius = self.length / sin(radians(self.steering))
            angular_velocity = self.velocity.x / turning_radius
        else:
            angular_velocity = 0
        self.position += self.velocity.rotate(-self.angle) * dt

        self.angle += degrees(angular_velocity) * dt
################################################################################
class O_Car:
    def __init__(self,vel, x, y):
        self.position = Vector2(x, y)
        #self.velocity = Vector2(vel, 0.0)
        #self.length = length
        #self.max_velocity = 5
        self.velocity=(0,vel)
    def update(self,dt):
       
        self.position += np.array(self.velocity) * dt
        #print(np.array(self.velocity) * dt)
################################################################################
class Start:
    def __init__(self):
        pygame.init()
        width ,height = 203 ,1000
        self.screen = pygame.display.set_mode((width, height))
        self.clock = pygame.time.Clock()
        self.ticks = 60
        self.exit = False

    def run(self):
# Loading image
        current_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(current_dir, "car.jpg")
        path1 = os.path.join(current_dir, "amu.jpg")
        path2 = os.path.join(current_dir, "car1.png")
        path3 = os.path.join(current_dir, "car2.png")
        path4 = os.path.join(current_dir, "car3.png")
        path5 = os.path.join(current_dir, "car4.png")
        path6 = os.path.join(current_dir, "car5.png")

        car_image = pygame.image.load(path)
        amu_image = pygame.image.load(path1)
        car_image1 = pygame.image.load(path2)
        car_image2 = pygame.image.load(path3)
        car_image3 = pygame.image.load(path4)
        car_image4 = pygame.image.load(path5)
        car_image5 = pygame.image.load(path6)
# Cars Location
        car = EGO_Car(2.9,18.5,angle=90.0)
        amu = EGO_Car(2.9,21,angle=90.0)
        car1=O_Car(4.9,2.9,15)### middel car
        car2=O_Car(4.9,5,16.7)### Top-left car
        car3=O_Car(4.7,5,19)
        car4=O_Car(4.97,1.3,20.5)### Top-right car
        car5=O_Car(4.87,1.2,22.5)

        ppu = 32
        
        while not self.exit:
            dt = self.clock.get_time() / 1000
            
            # Event queue
            for event in pygame.event.get():
                pressed = pygame.key.get_pressed()
                if event.type == pygame.QUIT or pressed[pygame.K_ESCAPE]:
                    self.exit = True

            # User input for ambulance
####################################################################
            if pressed[pygame.K_SPACE]:
                if amu.velocity.x < 0:
                    amu.acceleration = amu.brake_deceleration        
                else:
                    amu.acceleration += 1 * dt
            else:
                if abs(amu.velocity.x) > dt *amu.free_deceleration:
                    amu.acceleration = -copysign(amu.free_deceleration, amu.velocity.x)
                else:
                    if dt != 0:
                        amu.acceleration = -amu.velocity.x / dt
            amu.acceleration = max(-amu.max_acceleration, min(amu.acceleration, amu.max_acceleration))
             # User input for host car
####################################################################################            

            if pressed[pygame.K_UP]:
                if car.velocity.x < 0:
                    car.acceleration = car.brake_deceleration
                else:
                    car.acceleration += 1 * dt
            elif pressed[pygame.K_DOWN]:
                if car.velocity.x > 0:
                    car.acceleration = -1*car.brake_deceleration
                else:
                    car.acceleration -= 1 * dt
            else:
                if abs(car.velocity.x) > dt * car.free_deceleration:
                    car.acceleration = -copysign(car.free_deceleration, car.velocity.x)
                else:
                    if dt != 0:
                        car.acceleration = -car.velocity.x / dt
            car.acceleration = max(-car.max_acceleration, min(car.acceleration, car.max_acceleration))
            

            if pressed[pygame.K_RIGHT]:
                car.steering -= 30 * dt
            elif pressed[pygame.K_LEFT]:
                car.steering += 30 * dt
            else:
                car.steering = 0
            car.steering = max(-car.max_steering, min(car.steering, car.max_steering))

################################################################################################
           # Logic
            car.update(dt)
            amu.update(dt)
            car1.update(-dt)
            car2.update(-dt)
            car3.update(-dt)
            car4.update(-dt)
            car5.update(-dt)
            
           

            
            car.position_disp = np.array((car.position[0], car.position[1]))
            amu.position_disp = np.array((amu.position[0], amu.position[1]))
            car1.position_disp = np.array((car1.position[0], car1.position[1]))
            car2.position_disp = np.array((car2.position[0], car2.position[1]))
            car3.position_disp = np.array((car3.position[0], car3.position[1]))
            car4.position_disp = np.array((car4.position[0], car4.position[1]))
            car5.position_disp = np.array((car5.position[0], car5.position[1]))
           # print(np.array(car3.velocity-car2.velocity))
            #print(tuple(map(lambda i, j: i - j, np.array(car3.velocity), np.array(car2.velocity)))[1])
#####P_ego-P_amu,P_v1-P_ego,P_v2-P_v3,P_v4-P_v5,V_ego-V_amu,V_v1-V_ego,V_v2-V_v3,V_v4-V_v5,Lat pos,Lat vel,Long vel,acceleration,steer angle
	    #Data writing
            if car.position_disp[1]> 0:
            	outFile = open('/home/m/Desktop/Turn Front Left ','a')
            	outFile.write(str(car.position_disp[1]-amu.position_disp[1]))#اختلاف مکان طولی امبولانس و خودرو مهمان
            	outFile.write(",") 
            	outFile.write(str(car1.position_disp[1]-car.position_disp[1]))# اختلاف مکان طولی خودرو جلو مهمان و مهمان
            	outFile.write(",") 
            	outFile.write(str(car2.position_disp[1]-car3.position_disp[1]))#اختلاف مکان طولی خودرو دو و سه 
            	outFile.write(",") 
            	outFile.write(str(car4.position_disp[1]-car5.position_disp[1]))#اختلاف مکان طولی خودرو چهار و پنج
            	outFile.write(",") 
            	outFile.write(str(tuple(map(lambda i,j:i-j,np.array(car.velocity),np.array(amu.velocity)))[1]))##اختلاف سرعت طولی امبولانس و خودرو مهمان
            	outFile.write(",") 
            	outFile.write(str(tuple(map(lambda i,j:i-j,np.array(car1.velocity),np.array(car.velocity)))[1]))#اختلاف سرعت طولی خودرو جلو مهمان و مهمان 
            	outFile.write(",") 
            	outFile.write(str(tuple(map(lambda i,j:i-j,np.array(car2.velocity),np.array(car3.velocity)))[1]))##اختلاف سرعت طولی خودرو دو وسه
            	outFile.write(",") 
            	outFile.write(str(tuple(map(lambda i,j:i-j,np.array(car4.velocity),np.array(car5.velocity)))[1]))#اختلاف سرعت طولی خودرو چهار و پنج
            	outFile.write(",") 
            	outFile.write(str(car.position_disp[0]))#مکان عرضی خودرو مهمان
            	outFile.write(",") 
            	outFile.write(str(car.velocity.rotate(-car.angle)[0]))#سرعت عرضی  خودرو مهمان
            	outFile.write(",") 
            	outFile.write(str(car.velocity.rotate(-car.angle)[1]))# سرعت طولی خودرو مهمان
            	outFile.write(",") 
            	outFile.write(str(car.acceleration))#شتاب خودرو مهمان
            	outFile.write(",") 
            	outFile.write(str(car.steering))# زاویه فرمان خودرو مهمان
            	outFile.write("\n")






            # Drawing
            self.screen.fill((150, 150, 150))
            pygame.draw.rect(self.screen,(255, 255, 255) , [8, 0, 6, 970])##[left, top, width, height]
            pygame.draw.rect(self.screen,(255, 255, 255) , [189, 0, 6, 970])
            lane_positions_1 = [[65, 1000-i*80, 6, 50] for i in range(1000)]
            lane_positions_2 = [[127, 1000-i*80, 6, 50] for i in range(1000)]
            for p in lane_positions_1:
                p_disp = p
                pygame.draw.rect(self.screen,(255, 255, 255), p_disp)
            for H in lane_positions_2:
                p_disp = H
                pygame.draw.rect(self.screen,(255, 255, 255), p_disp)     
      





            rotated  = pygame.transform.rotate(car_image, car.angle)
            rotated_amu  = pygame.transform.rotate(amu_image, amu.angle)
            rotated1 = car_image1 
            rotated2 = car_image2
            rotated3 = car_image3
            rotated4 = car_image4 
            rotated5 = car_image5

 
            rect = rotated.get_rect()
            rect_amu = rotated_amu.get_rect()
            rect1 = rotated1.get_rect()
            rect2 = rotated2.get_rect()
            rect3 = rotated3.get_rect()
            rect4 = rotated4.get_rect()
            rect5 = rotated5.get_rect()
            
            self.screen.blit(rotated, car.position_disp * ppu - (rect.width / 10, rect.height / 10))
            self.screen.blit(rotated_amu, amu.position_disp * ppu - (rect_amu.width / 10, rect_amu.height / 10))
            self.screen.blit(rotated1, car1.position_disp * ppu - (rect1.width / 2, rect1.height / 2))
            self.screen.blit(rotated2, car2.position_disp * ppu - (rect2.width / 2, rect2.height / 2))
            self.screen.blit(rotated3, car3.position_disp * ppu - (rect3.width / 2, rect3.height / 2))
            self.screen.blit(rotated4, car4.position_disp * ppu - (rect4.width / 2, rect4.height / 2))
            self.screen.blit(rotated5, car5.position_disp * ppu - (rect5.width / 2, rect5.height / 2))



            pygame.display.flip()

            self.clock.tick(self.ticks)
        pygame.quit()
       # elapsed = (time.clock() - start)
       # print(elapsed)

################################################################################
if __name__ == '__main__':
    game = Start()
    game.run()
